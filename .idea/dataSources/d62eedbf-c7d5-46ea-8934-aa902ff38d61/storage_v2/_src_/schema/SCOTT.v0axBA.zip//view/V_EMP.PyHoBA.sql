create view V_EMP as
SELECT empno, ename, deptno
    FROM emp
/

