create view V_EMP_INFO as
select e.empno empno, e.ename ename, d.dname dname
from emp e, dept d
where e.deptno = d.deptno
/

