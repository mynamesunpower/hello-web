create view V_DEPT_SUM as
SELECT d.dname, 
min(sal) as min,
max(sal) as max,
round(avg(sal)) as avg
FROM emp e INNER JOIN dept d
ON e.deptno = d.deptno
GROUP BY d.dname
/

